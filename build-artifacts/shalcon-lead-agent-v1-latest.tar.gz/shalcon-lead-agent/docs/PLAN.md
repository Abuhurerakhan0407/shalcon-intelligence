# Shalcon Lead Agent — V1 Execution Plan

## Product goal
Turn Shalcon's LinkedIn/outbound workflow into an AI-native sales operating system that researches, scores, drafts, queues, tracks and learns while keeping risky external actions behind approval.

## V1 modules
1. Command Center
2. Leads
3. Research
4. Lead Scoring
5. Campaigns
6. Approval Queue
7. Message Copilot
8. CRM
9. Content Agent
10. Analytics

## Workstreams
### A — Product/UI
- App shell + navigation
- Command Center
- Leads table/detail
- Campaign builder
- Approval inbox
- CRM pipeline
- Content calendar
- Analytics

### B — Agent/backend
- Research contract
- ICP scoring contract
- Message drafting contract
- Action policy engine
- Goal planner
- Human approval checkpoint
- Audit log

### C — Data/integrations
- Supabase schema + RLS
- CSV/manual imports
- public website research adapter
- LinkedIn OAuth/app placeholders
- Gmail adapter
- Google Calendar adapter
- LinkedIn Lead Sync adapter (later approval dependent)

## Free-first rules
- Supabase Free
- Vercel Hobby while eligible for development/testing
- GitHub
- AI Gateway free/credit-backed models only when available; provider is swappable
- No paid enrichment dependency in V1
- No unauthorized LinkedIn scraping or browser automation

## Definition of done
- Authenticated Shalcon user can import/create leads
- Research output stored per lead
- 0–100 scoring with explanation
- Campaign can queue leads
- AI drafts connection/DM/email copy
- External outbound action requires approval
- CRM stage changes tracked
- Content draft workflow works
- Dashboard shows pipeline + task metrics
- Security/RLS checks pass
