# V1 Architecture

## Request path
UI -> Next.js route/server action -> policy check -> agent/workflow -> Supabase -> approval gate -> authorized external adapter.

## Agent roles
- Research Agent: public-web/company research only.
- Scoring Agent: deterministic rubric + AI explanation.
- Outreach Agent: creates drafts; cannot send in V1.
- Content Agent: drafts/schedules; publishing approval required.
- Goal Planner: turns natural-language goal into executable steps.

## Approval invariant
No LinkedIn connection, LinkedIn DM, outbound email, or public post may execute without an approval record in `approved` state unless a future adapter has explicit approved API authorization and policy is intentionally changed.

## Integrations
- LinkedIn: OAuth + approved APIs only. No browser bot/scraper.
- Gmail: approved sends after human approval.
- Google Calendar: meeting creation/availability.
- Public research: website fetch/search adapter with source URLs retained.

## Data
Supabase Postgres. Every business row carries `organization_id`. RLS scopes reads/writes to current user's organization.
