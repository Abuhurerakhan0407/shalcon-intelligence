import type { AgentTask, Lead } from "@/lib/types/domain";

export const metrics = [
  { label: "Prospects analysed", value: "142", delta: "+18 today" },
  { label: "Qualified", value: "37", delta: "26% pass rate" },
  { label: "Approvals waiting", value: "18", delta: "Connections + DMs" },
  { label: "Hot leads", value: "7", delta: "Score 85+" },
  { label: "Meetings", value: "2", delta: "This week" },
];

export const hotLeads: Lead[] = [
  { id: "1", name: "Rohan Mehta", title: "Founder", company: "Nova Clinics", location: "Mumbai", industry: "Healthcare", score: 94, status: "qualified", opportunity: "WhatsApp appointment qualification", signal: "Runs paid lead campaigns" },
  { id: "2", name: "Priya Shah", title: "Director", company: "BrightPath Academy", location: "Pune", industry: "EdTech", score: 91, status: "ready_to_connect", opportunity: "Admissions + enquiry automation", signal: "Multiple branches" },
  { id: "3", name: "Kabir Jain", title: "Owner", company: "ShieldSure", location: "Mumbai", industry: "Insurance", score: 89, status: "messaging", opportunity: "Renewal follow-up automation", signal: "Hiring operations staff" },
  { id: "4", name: "Ananya Rao", title: "Co-founder", company: "UrbanCart", location: "Bengaluru", industry: "E-commerce", score: 87, status: "qualified", opportunity: "Abandoned-cart recovery", signal: "High paid-social activity" },
];

export const tasks: AgentTask[] = [
  { id: "t1", label: "Research Mumbai clinics", state: "done", detail: "52 companies enriched from public web sources" },
  { id: "t2", label: "Score new leads", state: "running", detail: "83 leads queued against Shalcon ICP" },
  { id: "t3", label: "Connection notes", state: "approval", detail: "18 messages require human approval" },
  { id: "t4", label: "Tomorrow's LinkedIn post", state: "done", detail: "Healthcare automation angle drafted" },
  { id: "t5", label: "Follow-up replies", state: "approval", detail: "4 prospect responses need review" },
];
