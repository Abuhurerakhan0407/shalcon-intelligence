create or replace function private.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  new_org_id uuid;
begin
  insert into public.organizations(name)
  values (coalesce(new.raw_user_meta_data ->> 'organization_name', 'Shalcon Intelligence'))
  returning id into new_org_id;

  insert into public.profiles(id, full_name)
  values (new.id, coalesce(new.raw_user_meta_data ->> 'full_name', split_part(new.email, '@', 1)));

  insert into public.organization_members(organization_id, user_id, role)
  values (new_org_id, new.id, 'owner');

  insert into public.integrations(organization_id, provider, status)
  values
    (new_org_id, 'linkedin', 'pending'),
    (new_org_id, 'gmail', 'disconnected'),
    (new_org_id, 'google_calendar', 'disconnected'),
    (new_org_id, 'ai_gateway', 'disconnected');

  return new;
end;
$$;
revoke all on function private.handle_new_user() from public;
