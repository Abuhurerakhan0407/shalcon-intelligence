-- Enforce tenant consistency across all cross-table references.
-- Existing single-column foreign keys stay in place; these composite FKs add org ownership invariants.

alter table public.companies add constraint companies_id_org_unique unique (id, organization_id);
alter table public.leads add constraint leads_id_org_unique unique (id, organization_id);
alter table public.campaigns add constraint campaigns_id_org_unique unique (id, organization_id);
alter table public.agent_runs add constraint agent_runs_id_org_unique unique (id, organization_id);
alter table public.message_drafts add constraint message_drafts_id_org_unique unique (id, organization_id);

alter table public.leads
  add constraint leads_company_same_org_fk
  foreign key (company_id, organization_id)
  references public.companies(id, organization_id);

alter table public.lead_research
  add constraint lead_research_lead_same_org_fk
  foreign key (lead_id, organization_id)
  references public.leads(id, organization_id) on delete cascade,
  add constraint lead_research_company_same_org_fk
  foreign key (company_id, organization_id)
  references public.companies(id, organization_id) on delete cascade;

alter table public.campaign_leads
  add constraint campaign_leads_campaign_same_org_fk
  foreign key (campaign_id, organization_id)
  references public.campaigns(id, organization_id) on delete cascade,
  add constraint campaign_leads_lead_same_org_fk
  foreign key (lead_id, organization_id)
  references public.leads(id, organization_id) on delete cascade;

alter table public.message_drafts
  add constraint message_drafts_lead_same_org_fk
  foreign key (lead_id, organization_id)
  references public.leads(id, organization_id) on delete cascade,
  add constraint message_drafts_campaign_same_org_fk
  foreign key (campaign_id, organization_id)
  references public.campaigns(id, organization_id) on delete set null;

alter table public.activities
  add constraint activities_lead_same_org_fk
  foreign key (lead_id, organization_id)
  references public.leads(id, organization_id) on delete cascade,
  add constraint activities_campaign_same_org_fk
  foreign key (campaign_id, organization_id)
  references public.campaigns(id, organization_id) on delete set null;

alter table public.approvals
  add constraint approvals_lead_same_org_fk
  foreign key (lead_id, organization_id)
  references public.leads(id, organization_id) on delete cascade,
  add constraint approvals_campaign_same_org_fk
  foreign key (campaign_id, organization_id)
  references public.campaigns(id, organization_id) on delete set null,
  add constraint approvals_agent_run_same_org_fk
  foreign key (agent_run_id, organization_id)
  references public.agent_runs(id, organization_id) on delete set null;
