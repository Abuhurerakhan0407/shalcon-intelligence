create extension if not exists pgcrypto;

create schema if not exists private;
revoke all on schema private from public;
grant usage on schema private to authenticated;

create type public.lead_status as enum (
  'discovered','qualified','ready_to_connect','connection_sent','accepted',
  'messaging','interested','meeting','proposal','won','lost'
);
create type public.approval_status as enum ('pending','approved','rejected','executed','expired');
create type public.agent_run_state as enum ('queued','running','waiting_approval','completed','failed','cancelled');

create table public.organizations (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  created_at timestamptz not null default now()
);

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.organization_members (
  organization_id uuid not null references public.organizations(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null default 'member' check (role in ('owner','admin','member')),
  created_at timestamptz not null default now(),
  primary key (organization_id, user_id)
);
create index organization_members_user_idx on public.organization_members(user_id);

create table public.companies (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  name text not null,
  website text,
  industry text,
  location text,
  employee_range text,
  linkedin_url text,
  summary text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index companies_org_idx on public.companies(organization_id);
create unique index companies_org_website_unique on public.companies(organization_id, lower(website)) where website is not null;

create table public.leads (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  company_id uuid references public.companies(id) on delete set null,
  full_name text not null,
  job_title text,
  linkedin_url text,
  email text,
  phone text,
  location text,
  source text not null default 'manual',
  status public.lead_status not null default 'discovered',
  score int not null default 0 check (score between 0 and 100),
  score_breakdown jsonb not null default '{}'::jsonb,
  opportunity text,
  recommended_offer text,
  buying_signals jsonb not null default '[]'::jsonb,
  tags text[] not null default '{}',
  last_activity_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index leads_org_idx on public.leads(organization_id);
create index leads_org_status_idx on public.leads(organization_id, status);
create index leads_org_score_idx on public.leads(organization_id, score desc);
create unique index leads_org_linkedin_unique on public.leads(organization_id, lower(linkedin_url)) where linkedin_url is not null;
create unique index leads_org_email_unique on public.leads(organization_id, lower(email)) where email is not null;

create table public.lead_research (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  lead_id uuid not null references public.leads(id) on delete cascade,
  company_id uuid references public.companies(id) on delete cascade,
  summary text,
  pain_points jsonb not null default '[]'::jsonb,
  automation_opportunities jsonb not null default '[]'::jsonb,
  buying_signals jsonb not null default '[]'::jsonb,
  evidence jsonb not null default '[]'::jsonb,
  confidence numeric(4,3) check (confidence is null or (confidence >= 0 and confidence <= 1)),
  researched_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);
create index lead_research_org_idx on public.lead_research(organization_id);
create index lead_research_lead_idx on public.lead_research(lead_id, researched_at desc);

create table public.campaigns (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  name text not null,
  objective text not null,
  offer text,
  status text not null default 'draft' check (status in ('draft','active','paused','completed','archived')),
  icp jsonb not null default '{}'::jsonb,
  channels text[] not null default '{linkedin}',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index campaigns_org_idx on public.campaigns(organization_id);

create table public.campaign_leads (
  organization_id uuid not null references public.organizations(id) on delete cascade,
  campaign_id uuid not null references public.campaigns(id) on delete cascade,
  lead_id uuid not null references public.leads(id) on delete cascade,
  state text not null default 'queued',
  added_at timestamptz not null default now(),
  primary key (campaign_id, lead_id)
);
create index campaign_leads_org_idx on public.campaign_leads(organization_id);

create table public.message_drafts (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  lead_id uuid not null references public.leads(id) on delete cascade,
  campaign_id uuid references public.campaigns(id) on delete set null,
  channel text not null check (channel in ('linkedin_connection','linkedin_dm','email','whatsapp')),
  stage text not null default 'first_touch',
  subject text,
  body text not null,
  personalization jsonb not null default '{}'::jsonb,
  status text not null default 'draft' check (status in ('draft','approved','used','discarded')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index message_drafts_org_idx on public.message_drafts(organization_id);
create index message_drafts_lead_idx on public.message_drafts(lead_id, created_at desc);

create table public.activities (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  lead_id uuid references public.leads(id) on delete cascade,
  campaign_id uuid references public.campaigns(id) on delete set null,
  type text not null,
  channel text,
  payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index activities_org_idx on public.activities(organization_id);
create index activities_lead_idx on public.activities(lead_id, created_at desc);

create table public.approvals (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  lead_id uuid references public.leads(id) on delete cascade,
  campaign_id uuid references public.campaigns(id) on delete set null,
  agent_run_id uuid,
  action text not null,
  payload jsonb not null,
  status public.approval_status not null default 'pending',
  requested_by text not null default 'agent',
  decided_by uuid references auth.users(id),
  decided_at timestamptz,
  expires_at timestamptz,
  created_at timestamptz not null default now()
);
create index approvals_org_status_idx on public.approvals(organization_id, status, created_at desc);

create table public.content_items (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  format text not null,
  pillar text,
  title text,
  body text,
  status text not null default 'draft' check (status in ('idea','draft','approval','approved','scheduled','published','archived')),
  scheduled_for timestamptz,
  published_at timestamptz,
  linkedin_post_urn text,
  metrics jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index content_items_org_idx on public.content_items(organization_id);

create table public.agent_runs (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  goal text not null,
  state public.agent_run_state not null default 'queued',
  plan jsonb not null default '[]'::jsonb,
  context jsonb not null default '{}'::jsonb,
  result jsonb not null default '{}'::jsonb,
  error jsonb,
  started_at timestamptz,
  completed_at timestamptz,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index agent_runs_org_state_idx on public.agent_runs(organization_id, state, created_at desc);

alter table public.approvals
  add constraint approvals_agent_run_fk foreign key (agent_run_id) references public.agent_runs(id) on delete set null;

create table public.integrations (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  provider text not null,
  status text not null default 'disconnected' check (status in ('disconnected','connected','error','pending')),
  external_account_id text,
  credential_ref text,
  metadata jsonb not null default '{}'::jsonb,
  connected_by uuid references auth.users(id),
  connected_at timestamptz,
  updated_at timestamptz not null default now(),
  unique (organization_id, provider)
);
create index integrations_org_idx on public.integrations(organization_id);

create table public.audit_logs (
  id bigint generated by default as identity primary key,
  organization_id uuid not null references public.organizations(id) on delete cascade,
  actor_user_id uuid references auth.users(id),
  actor_type text not null default 'user' check (actor_type in ('user','agent','system')),
  action text not null,
  entity_type text,
  entity_id uuid,
  data jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index audit_logs_org_idx on public.audit_logs(organization_id, created_at desc);

create or replace function private.current_org_ids()
returns setof uuid
language sql
stable
security definer
set search_path = ''
as $$
  select om.organization_id
  from public.organization_members om
  where om.user_id = (select auth.uid());
$$;
revoke all on function private.current_org_ids() from public;
grant execute on function private.current_org_ids() to authenticated;

create or replace function private.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  new_org_id uuid;
begin
  insert into public.organizations(name)
  values (coalesce(new.raw_user_meta_data ->> 'organization_name', 'Shalcon Intelligence'))
  returning id into new_org_id;

  insert into public.profiles(id, full_name)
  values (new.id, coalesce(new.raw_user_meta_data ->> 'full_name', split_part(new.email, '@', 1)));

  insert into public.organization_members(organization_id, user_id, role)
  values (new_org_id, new.id, 'owner');

  return new;
end;
$$;
revoke all on function private.handle_new_user() from public;

create trigger on_auth_user_created
after insert on auth.users
for each row execute function private.handle_new_user();

create or replace function private.set_updated_at()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create trigger profiles_updated_at before update on public.profiles for each row execute function private.set_updated_at();
create trigger companies_updated_at before update on public.companies for each row execute function private.set_updated_at();
create trigger leads_updated_at before update on public.leads for each row execute function private.set_updated_at();
create trigger campaigns_updated_at before update on public.campaigns for each row execute function private.set_updated_at();
create trigger message_drafts_updated_at before update on public.message_drafts for each row execute function private.set_updated_at();
create trigger content_items_updated_at before update on public.content_items for each row execute function private.set_updated_at();
create trigger agent_runs_updated_at before update on public.agent_runs for each row execute function private.set_updated_at();
create trigger integrations_updated_at before update on public.integrations for each row execute function private.set_updated_at();

alter table public.organizations enable row level security;
alter table public.profiles enable row level security;
alter table public.organization_members enable row level security;
alter table public.companies enable row level security;
alter table public.leads enable row level security;
alter table public.lead_research enable row level security;
alter table public.campaigns enable row level security;
alter table public.campaign_leads enable row level security;
alter table public.message_drafts enable row level security;
alter table public.activities enable row level security;
alter table public.approvals enable row level security;
alter table public.content_items enable row level security;
alter table public.agent_runs enable row level security;
alter table public.integrations enable row level security;
alter table public.audit_logs enable row level security;

create policy "profiles_self_select" on public.profiles for select to authenticated
using ((select auth.uid()) = id);
create policy "profiles_self_update" on public.profiles for update to authenticated
using ((select auth.uid()) = id) with check ((select auth.uid()) = id);

create policy "org_member_select" on public.organizations for select to authenticated
using (id in (select private.current_org_ids()));

create policy "members_same_org_select" on public.organization_members for select to authenticated
using (organization_id in (select private.current_org_ids()));

create policy "companies_org_all" on public.companies for all to authenticated
using (organization_id in (select private.current_org_ids()))
with check (organization_id in (select private.current_org_ids()));

create policy "leads_org_all" on public.leads for all to authenticated
using (organization_id in (select private.current_org_ids()))
with check (organization_id in (select private.current_org_ids()));

create policy "research_org_all" on public.lead_research for all to authenticated
using (organization_id in (select private.current_org_ids()))
with check (organization_id in (select private.current_org_ids()));

create policy "campaigns_org_all" on public.campaigns for all to authenticated
using (organization_id in (select private.current_org_ids()))
with check (organization_id in (select private.current_org_ids()));

create policy "campaign_leads_org_all" on public.campaign_leads for all to authenticated
using (organization_id in (select private.current_org_ids()))
with check (organization_id in (select private.current_org_ids()));

create policy "message_drafts_org_all" on public.message_drafts for all to authenticated
using (organization_id in (select private.current_org_ids()))
with check (organization_id in (select private.current_org_ids()));

create policy "activities_org_all" on public.activities for all to authenticated
using (organization_id in (select private.current_org_ids()))
with check (organization_id in (select private.current_org_ids()));

create policy "approvals_org_all" on public.approvals for all to authenticated
using (organization_id in (select private.current_org_ids()))
with check (organization_id in (select private.current_org_ids()));

create policy "content_org_all" on public.content_items for all to authenticated
using (organization_id in (select private.current_org_ids()))
with check (organization_id in (select private.current_org_ids()));

create policy "agent_runs_org_all" on public.agent_runs for all to authenticated
using (organization_id in (select private.current_org_ids()))
with check (organization_id in (select private.current_org_ids()));

create policy "integrations_org_all" on public.integrations for all to authenticated
using (organization_id in (select private.current_org_ids()))
with check (organization_id in (select private.current_org_ids()));

create policy "audit_org_select" on public.audit_logs for select to authenticated
using (organization_id in (select private.current_org_ids()));
create policy "audit_org_insert" on public.audit_logs for insert to authenticated
with check (organization_id in (select private.current_org_ids()));

-- Keep tokens/secrets out of public tables. Store only references/metadata here.
comment on column public.integrations.credential_ref is 'Opaque reference only; never store raw OAuth tokens here.';
