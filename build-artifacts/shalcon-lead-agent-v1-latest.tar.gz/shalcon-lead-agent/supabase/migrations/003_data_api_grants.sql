grant select on public.organizations, public.profiles, public.organization_members to authenticated;
grant select, insert, update, delete on public.companies, public.leads, public.lead_research, public.campaigns, public.campaign_leads, public.message_drafts, public.activities, public.approvals, public.content_items, public.agent_runs, public.integrations to authenticated;
grant select, insert on public.audit_logs to authenticated;
grant usage, select on sequence public.audit_logs_id_seq to authenticated;
